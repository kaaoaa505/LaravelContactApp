# Contact Manager Html tempalte

Application template for Contact Management Application on my Udemy Course

![alt text](https://bitbucket.org/edomaru/contact_management_template/raw/20eb9fecda1568d1a3bb9b681350ba1e8cdb55d4/img/screenshot.png "Screenshot")

- [Laravel 5 AJAX](https://www.udemy.com/course/learn-laravel-by-doing/)
- [Rails 5 Masterclass](https://www.udemy.com/course/rails-5-masterclass/)