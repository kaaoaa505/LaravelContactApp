<?php

namespace App\Scopes;

class ContactFilterScope extends FilterScope
{
    protected $filterColumns = ['company_id'];
}
