<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($id); ?>" <?php echo e(($company_id == $id || old('company_id') == $id) ? 'selected' : ''); ?>>
        <?php echo e($name); ?>

    </option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Programming\LaravelFramework\FromNovicetoProfessional\contact-app\resources\views/contacts/_companies_options.blade.php ENDPATH**/ ?>